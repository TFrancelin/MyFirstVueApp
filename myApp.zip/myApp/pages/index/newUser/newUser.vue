<template>
    <div>
        <h1>Hello boys</h1>
    </div>
</template>


<script>
export default {
    
}
</script>

<style lang="scss">

</style>
