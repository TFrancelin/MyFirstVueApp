<template>
	<view>
		<div class="container">
			<div class="logMainPage">
			<div class="logTitle">
				<h1>账号密码登录</h1>
				<div class="logList">
					<li>短信登录</li>
					<li>密码登录</li>
				</div>
			</div>
			<div class="logContent">
				<view>
					<u-field icon="phone" v-model="mobile" placeholder="手机号" required>
						<u-button size="mini" slot="right" type="success" @click="getCode">{{codeText}}</u-button>
					</u-field><hr>
				</view>
				<u-field icon="checkmark-circle-fill" v-model="code" required>
					<u-verification-code ref="uCode" @change="codeChange"></u-verification-code>
				</u-field>

				<view> 
					<u-button shape="circle">登入</u-button>
				</view>
			</div>
		</div>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				mobile: '',
				code: '',
				codeText: ''
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: white;
		width: 100%;
		height: 100%;
	}

	.logMainPage {
		margin: 90px 30px;
		width: 300px;
		height: 300px;
		border: 1px solid #eff5f5;
		border-radius: 10px;
  }

	.logTitle {
		text-align: center;
		font-family: arial sans-serif;
	}

	.logList {
		margin-left: 0 -50px;
		display: flex;
	}

	li {
		flex: 1;
		// list-style: none;
		margin: 15px;
		padding: 10px ;
		display: inline;
	}

	hr{
    margin: 2px 10px;
  	}

	u-field {
		display: flex;
	}
</style>
