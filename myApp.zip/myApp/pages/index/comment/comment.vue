<template>
	<view>
		<div class="container">
			<div class="logMainPage">
			<div class="logTitle">
				<h1>账号密码登录</h1>
				<div class="logList">
					<u-button class="btn" @click="change(0)">短信登录</u-button>
					<u-button class="btn" @click="change(1)">密码登录</u-button>
				</div>
			</div>
			<div class="logContent">
				<view v-if="login == 0" class="">
					<u-form :model="form" ref="uForm">
						<u-form-item prop="phone">
              <u-icon class="iconPhone" name="phone" size="35"></u-icon>
							<u-input icon="mobile" placeholder="手机号" v-model="form.phone" required />
							<u-verification-code :seconds="seconds" @end="end" @start="start" ref="uCode" @change="codeChange"></u-verification-code>
              <u-button class="wrap" @tap="getCode">{{tips}}</u-button>
            </u-form-item>
					</u-form>

					<u-form :model="form" ref="uForm">
						<u-form-item>
							<u-input icon="code" placeholder="" v-model="form.code"/>
						</u-form-item>
					</u-form>
          <u-button @click="codeLoginBtn()">登入</u-button>
				</view>

        <view v-if="login == 1" class="">
					<u-form :model="form" ref="uForm">
						<u-form-item prop="phone">
              <u-icon class="icon" name="phone" size="35"></u-icon>
							<u-input placeholder="phone number" type="number" v-model="form.phone" required />
						</u-form-item>
					</u-form>
					<u-form :model="form" ref="uForm">
						<u-form-item>
							<u-icon class="icon" name="lock" size="35"></u-icon>
							<u-input placeholder="password" v-model="form.password" required />
						</u-form-item>
					</u-form>
          <u-button @click="passLoginBtn()">登录</u-button>
				</view>
        
			</div>

      <div class="newUser">
        <u-button @click="resetPass()"><u-icon class="icon" name="lock"></u-icon>忘记密码</u-button>
        <u-button @click="register"><u-icon class="icon" name="photo"></u-icon>注册账号</u-button>
      </div>
		</div>
		</div>
	</view>
</template>

<script>
export default {
  data() {
    return {
      login: 0,
      form: {
        code: "",
        phone: "",
        password: "",
      },
      verification_key: "",
      tips: "",
      seconds: 60,
    };
  },
  onLoad() {},
  methods: {
    codeChange(text) {
      this.tips = text;
    },
    getCode() {
      if (this.$refs.uCode.canGetCode) {
        // 模拟向后端请求验证码
        uni.showLoading({
          title: "正在获取验证码",
        });
        setTimeout(() => {
          uni.hideLoading();
          // 这里此提示会被this.start()方法中的提示覆盖
          this.$u.toast("验证码已发送");
          // 通知验证码组件内部开始倒计时
          this.$refs.uCode.start();
        }, 2000);
      } else {
        this.$u.toast("倒计时结束后再发送");
      }

      uni.request({
        url: "https://gyltest.mouldc.com/api/registration/forgetpassword", //仅为示例，并非真实接口地址。
        data: {
          phone: this.form.phone,
        },
        method: "POST",
        header: {
          "custom-header": "hello", //自定义请求头信息
        },
        success: (res) => {
          console.log(res.data.msg);
        },
      });
    },
    end() {
      this.$u.toast("倒计时结束");
    },
    start() {
      this.$u.toast("倒计时开始");
    },
    change(type) {
      this.login = type;
    },
    codeLoginBtn() {
      console.log(this.form.code);
      uni.request({
        url: "https://gyltest.mouldc.com/api/verification",
        data: {
          code: this.form.code,
          verification_key: this.verification_key,
        },
        method: "POST",
        success: (res) => {
          this.verification_key = res.data.key.key;
          let code = this.verification_key;
          console.log(code);
        },
      });
    },
    passLoginBtn() {
      console.log(this.form);
      uni.request({
        url: "https://gyltest.mouldc.com/api/authorizations", //仅为示例，并非真实接口地址。
        data: {
          username: this.form.phone,
          password: this.form.password,
        },
        method: "POST",
        success: (res) => {
          console.log(res);
        },
      });
    },
    resetPass(){
	 console.log(this.$router)
	 uni.navigateTo({
		url: '../newUser/newUser'
	 })

    },
    register(){
      this.$router.push({
		  path: 'pages/index/newUser/newUser',
		  animationType: 'pop-in',
	});
    }
  },
};
</script>

<style lang="scss">
.container {
  background-color: white;
  width: 100%;
  height: 100%;
}

.logMainPage {
  margin: 90px 30px;
  width: 300px;
  height: 300px;
}

.logTitle {
  text-align: center;
  font-family: arial sans-serif;
}

.logList {
  margin-left: 0 -50px;
  margin-top: 40px;
  display: flex;
}

.iconPhone {
  margin-right: 8px;
}

hr {
  margin: 2px 10px;
}

.wrap {
  padding: 24rpx;
  background-color: rgba(91, 245, 122, 0.815);
}

u-field {
  display: flex;
}

.newUser {
  display: flex;
  margin-top: 10px;
}

.newUser > button {
  flex: 1;
  position: relative;
  margin-top: 20px;
  margin-left: 20px;
  border: none;
  background-color: none;
}

// .newUser > button:not(:last-child)::after {
//   content: "";
//   position: absolute;
//   right: 15px;
//   height: 15px;
//   width: 1px;
//   margin-top: 2px;
//   background-color: #d4d5d6;
// }

.icon {
  margin-right: 10px;
}
</style>
