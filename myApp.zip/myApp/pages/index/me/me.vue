<template>
	<view>
		<div>
      		<div class="page-4th-1st-part">
      			<img src="https://obs-sm-store.obs.cn-east-3.myhuaweicloud.com//assets/images/LOGO.png" alt="zhongmoyun">
				<p>登录/注册</p>
				<div class="order">
					<p><span>--</span>我价次数<p>|</p></p>
					<p><span>--</span>订单进行中<p>|</p></p>
					<p><span>--</span>历史订单</p>
				</div>
    		</div>

    		<div class="notif-bar">
      			<u-notice-bar type="info" :more-icon="true" :autoplay="true" :volume-icon="true" mode="horizontal" :is-circular="false" :list="notification"></u-notice-bar>
    		</div>

    		<div class="page-4th-2nd-part">

    		</div>
  		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				notification:[
					'Hello guys, welcome to Zhongmoyun!',
					'Here is your fav shop',
					'Everything you want is available',
					'Let\'s shop boys'
				]
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
  .page-4th {
    height: 700px;
  }
  
  .page-4th-1st-part {
  width: 98%;
  height: 150px;
  margin: 10px 2px;
  background-color: rgb(224, 237, 242);
  border: solid 1px black;
  border-radius: 10px;
}

.page-4th-1st-part>img {
  position: relative;
  left: 40px;
  top: 20px;
  height: 40px;
  width: 40px;
  border: 2px solid skyblue;
  border-radius: 50%;
}

.page-4th-1st-part > p {
	display: inline;
	margin-left: 45px;
}

.order {
	position: relative;
	top: 60px;
	display: flex;
	justify-content: space-around;
}

.order>span {
	
}

.order>p {
	
}

.notif-bar {
  margin: 5px 10px;
  background-color: white;
}

.page-4th-2nd-part {
  
}
</style>
