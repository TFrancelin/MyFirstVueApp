<template>
	<view>
		<div>
      		<div class="page-4th-1st-part">
      			<img src="https://obs-sm-store.obs.cn-east-3.myhuaweicloud.com//assets/images/LOGO.png" alt="zhongmoyun">
				<p>登录/注册</p>
				<div class="order">
					<p><span>--</span>我价次数</p>
					<p><span>--</span>订单进行中</p>
					<p><span>--</span>历史订单</p>
				</div>
    		</div>

    		<div class="notif-bar">
      			<u-notice-bar type="info" :more-icon="true" :autoplay="true" :volume-icon="true" mode="horizontal" :is-circular="false" :list="notification"></u-notice-bar>
    		</div>

    		<div class="page-4th-2nd-part">
				<p class="title">我的服务</p>
				<div class="iconHolder">
					<p><u-icon name="order" color="#cfdeee" size="60"></u-icon><span>我的询盘</span></p>
					<p><u-icon name="file-text" color="#cfdeee" size="60"></u-icon><span>发布询盘</span></p>
					<p><u-icon name="bookmark" color="#cfdeee" size="60"></u-icon><span>我的订单</span></p>
					<p><u-icon name="bag" color="#cfdeee" size="60"></u-icon><span>我的收藏</span></p>
					<p><u-icon name="setting" color="#cfdeee" size="60"></u-icon><span>账户与安全</span></p>
					<p><u-icon name="server-man" color="#cfdeee" size="60"></u-icon><span>客服</span></p>
				</div>
    		</div>
  		</div>
	</view>
</template>

<script>
export default {
  data() {
    return {
      notification: [
        "Hello guys, welcome to Zhongmoyun!",
        "Here is your favorite shop.",
        "Everything you want is available in here.",
        "Let's shop boys!",
      ],
    };
  },
  methods: {},
};
</script>

<style lang="scss">
.page-4th {
  height: 700px;
}

.page-4th-1st-part {
  width: 98%;
  height: 150px;
  margin: 10px 2px;
  background-color: rgb(224, 237, 242);
  border: solid 1px black;
  border-radius: 10px;
}

.page-4th-1st-part > img {
  position: relative;
  left: 40px;
  top: 20px;
  height: 40px;
  width: 40px;
  border: 2px solid skyblue;
  border-radius: 50%;
}

.page-4th-1st-part > p {
  display: inline;
  margin-left: 45px;
}

.order {
  position: relative;
  top: 60px;
  display: flex;
  justify-content: space-around;
}

.order > p > span {
  display: block;
  text-align: center;
}

.order > p {
  position: relative;
  flex: 1;
  text-align: center;
}

.order > p:not(:last-child):after {
  content: "";
  position: absolute;
  right: 0;
  top: 50%;
  margin-top: -10px;
  height: 20px;
  width: 1px;
  background-color: #000;
}

.bar {
  position: absolute;
  top: 10px;
  left: 5px;
}

.notif-bar {
  margin: 5px 10px;
  background-color: white;
}

.page-4th-2nd-part {
  width: 365px;
  height: 200px;
  border: 2px solid whitesmoke;
  border-radius: 10px;
}

.page-4th-2nd-part > .title {
  font-size: 15px;
  font-weight: 500;
  margin-left: 15px;
  margin-top: 15px;
}

.iconHolder {
  display: grid;
  grid-template-columns: repeat(3, 10fr);
  grid-template-rows: repeat(2, 10fr);
  grid-gap: 20px;
  margin-left: 20px;
  margin-top: 20px;
}

.iconHolder > p {
  text-align: center;
  position: relative;

  span {
    display: block;
    margin-top: 10px;
  }
}

.iconHolder > p:not(:nth-child(3n)):after{
	content: "";
	position: absolute;
	right: 0;
	top: 50%;
	height: 20px;
	width: 1px;
	background-color: #d4d5d6;
}
</style>
