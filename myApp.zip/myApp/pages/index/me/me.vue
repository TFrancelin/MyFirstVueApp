<template>
	<view>
		<div>
      		<div class="page-4th-1st-part">
      			<img src="https://obs-sm-store.obs.cn-east-3.myhuaweicloud.com//assets/images/LOGO.png" alt="zhongmoyun">
    		</div>

    		<div class="notif-bar">
      			<u-notice-bar type="info" :more-icon="true" :autoplay="true" :volume-icon="true" mode="horizontal" :is-circular="false" :list="notification"></u-notice-bar>
    		</div>

    		<div class="page-4th-2nd-part">

    		</div>
  		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
  .page-4th {
    height: 700px;
  }
  
  .page-4th-1st-part {
  width: 98%;
  height: 150px;
  margin: 10px 2px;
  background-color: rgb(224, 237, 242);
  border: solid 1px black;
  border-radius: 10px;
}

.page-4th-1st-part>img {
  position: relative;
  left: 30px;
  top: 20px;
  height: 40px;
  width: 40px;
}

.notif-bar {
  margin: 5px 10px;
  background-color: white;
}

.page-4th-2nd-part {
  
}
</style>
