 <template>
  <div class="container">
    <div class="navbar">
      <p class="appTitle">{{ appTitle }}</p>
      <u-icon name="email" class="iconMail"></u-icon>
    </div>  
      
    <div class="search">
      <u-search :clearabled="true" class="search-box" placeholder="Search" shape="square" v-model="keyword" bg-color="white"></u-search>
    </div>

    <div v-if="current == 0">
      <div>
        <view class="content">
          <view class="wrap">
            <u-swiper :list="carouselList"></u-swiper>
          </view>
        </view>
      </div>

      <div class="">
        <div class="columns1">
          <div>19家</div>
          <div>42单</div>
          <div>77单</div>
        </div>

        <div class="columns2">
          <div>入驻企业</div>
          <div>促成交易</div>
          <div>正在竞价</div>
        </div>
      </div>

      <div>
        <swiper class="swiper" @change="change">
          <swiper-item>
            <u-grid :col="4" @click="click" hover-class="hover-class">
              <u-grid-item v-for="(item, index) in navlistone" :index="index" :key="index">
                <u-icon :name="item" :size="46"></u-icon>
                <text class="grid-text">{{ '宫格' + (index + 1) }}</text>
              </u-grid-item>
            </u-grid>
          </swiper-item>
        <swiper-item>
          <u-grid :col="4" @click="click" hover-class="hover-class">
            <u-grid-item v-for="(item, index) in navlisttwo" :index="index" :key="index">
              <u-icon :name="item" :size="46"></u-icon>
              <text class="grid-text">{{ '宫格' + (index + 1) }}</text>
            </u-grid-item>
          </u-grid>
        </swiper-item>
      </swiper>
        <view class="indicator-dots" v-if="isSwiper">
          <view class="indicator-dots-item" :class="[current == 0 ? 'indicator-dots-active' : '']">
          </view>
          <view class="indicator-dots-item" :class="[current == 1 ? 'indicator-dots-active' : '']">
          </view>	
        </view>
      </div>



      <div>
        <div class="cell">
          <u-cell-group>
            <u-cell-item icon="tags" title="个人设置"></u-cell-item><hr style="margin: 0 5%">
            <view>
              <scroll-view style="height:50rpx" :scroll-top="scrollTop" scroll-y="true" class="scroll-Y" @scrolltoupper="upper" @scrolltolower="lower"
                @scroll="scroll">
                  <view id="demo1" class="scroll-view-item uni-bg-red">Lorem Ipsum is simply dummy text of the printing and</view>
                  <view id="demo2" class="scroll-view-item uni-bg-green">Typesetting industry. Lorem Ipsum has been</view>
                  <view id="demo3" class="scroll-view-item uni-bg-blue">The industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</view>
              </scroll-view>
            </view>
          </u-cell-group>
        </div>
        <div class="cell">
          <u-cell-group>
            <u-cell-item icon="list-dot" title="个人设置"></u-cell-item><hr style="margin: 0 5%">
            <view>
              <scroll-view style="height:50rpx" :scroll-top="scrollTop" scroll-y="true" class="scroll-Y" @scrolltoupper="upper" @scrolltolower="lower"
                @scroll="scroll">
                  <view id="demo1" class="scroll-view-item uni-bg-red">Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</view>
                  <view id="demo2" class="scroll-view-item uni-bg-green">It was popularised in the 1960s with the release of Letraset sheets containing</view>
                  <view id="demo3" class="scroll-view-item uni-bg-blue">It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</view>
              </scroll-view>
            </view>
          </u-cell-group>
        </div>
        <div class="cell">
          <u-cell-group>
            <u-cell-item icon="bookmark" title="个人设置"></u-cell-item><hr style="margin: 0 5%">
            <view>
              <scroll-view style="height:50rpx" :scroll-top="scrollTop" scroll-y="true" class="scroll-Y" @scrolltoupper="upper" @scrolltolower="lower"
                @scroll="scroll">
                  <view id="demo1" class="scroll-view-item uni-bg-red">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. </view>
                  <view id="demo2" class="scroll-view-item uni-bg-green">Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. </view>
                  <view id="demo3" class="scroll-view-item uni-bg-blue">Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</view>
              </scroll-view>
            </view>
          </u-cell-group>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      appTitle: "供应链让模具定制更简单",
      radio: "1",
      keyword: "Search",
      carouselList: [
        {
          image: "https://cdn.uviewui.com/uview/swiper/1.jpg",
          title: "昨夜星辰昨夜风，画楼西畔桂堂东",
        },
        {
          image: "https://cdn.uviewui.com/uview/swiper/2.jpg",
          title: "身无彩凤双飞翼，心有灵犀一点通",
        },
        {
          image: "https://cdn.uviewui.com/uview/swiper/3.jpg",
          title: "谁念西风独自凉，萧萧黄叶闭疏窗，沉思往事立残阳",
        },
      ],
      current: 0,
      navlistone: [
        "integral",
        "kefu-ermai",
        "coupon",
        "gift",
        "scan",
        "pause-circle",
        "wifi",
        "email",
      ],
      navlisttwo: ["integral", "kefu-ermai"],
      isSwiper: true,
      scrollTop: 0,
      old: {
        scrollTop: 0,
      },
    };
  },
  onLoad() {
    uni.request({
      url: "https://gyltest.mouldc.com/api/carousel", //仅为示例，并非真实接口地址。
      method: "POST",
      header: {
        "custom-header": "hello", //自定义请求头信息
      },
      success: (res) => {
        console.log(res.data.image);
        this.carouselList = res.data.image;
        let imageArr = res.data.image;
        let arr = [];
        imageArr.forEach((element) => {
          let obj = {
            image: element.image,
          };
          arr.push(obj);
        });
        console.log(arr);
      },
    });
  },
  methods: {
    change(e) {
      this.current = e.detail.current;
    },
    upper: function(e) {
      console.log(e);
    },
    lower: function(e) {
      console.log(e);
    },
    scroll: function(e) {
      console.log(e);
      this.old.scrollTop = e.detail.scrollTop;
    },
    goTop: function(e) {
      this.scrollTop = this.old.scrollTop;
      this.$nextTick(function() {
        this.scrollTop = 0;
      });
      uni.showToast({
        icon: "none",
        title: "纵向滚动 scrollTop 值已被修改为 0",
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.container {
  background-color: #eff5f5;
  height: 100%;
}

.appTitle {
  display: inline;
  text-align: center;
  margin-left: 100px;
  font-weight: 700;
}

.wrap {
  padding: 40rpx;
}

.iconMail {
  float: right;
  margin-right: 10px;
}

.columns1,
.columns2 {
  display: flex;
  margin: 0 20px;
  color: rgba(88, 171, 204, 0.918);
}

.columns1 > div,
.columns2 > div {
  flex: 1;
}

.search {
  margin-top: 5px;
}

.search-box {
  position: relative;
  left: 5px;
}

.grid-text {
  font-size: 28rpx;
  margin-top: 4rpx;
  color: $u-type-info;
}

/* 下方这些scss变量为uView内置变量，详见开发  组件-指南-内置样式 */

.grid-text {
  font-size: 28rpx;
  margin-top: 4rpx;
  color: $u-type-info;
}

.swiper {
  height: 280rpx;
}

.indicator-dots {
  margin-top: 40rpx;
  display: flex;
  justify-content: center;
  align-items: center;
}

.indicator-dots-item {
  background-color: $u-tips-color;
  height: 6px;
  width: 6px;
  border-radius: 10px;
  margin: 0 3px;
}

.indicator-dots-active {
  background-color: $u-type-primary;
}

.scroll-Y,
.cell,
#demo1,
#demo2,
#demo3 {
  margin-top: 7px;
}

.scroll-Y {
  min-height: 90px;
}

.page-4th {
  height: 700px;
}

.page-4th-1st-part {
  width: 98%;
  height: 150px;
  margin: 10px 2px;
  background-color: rgb(224, 237, 242);
  border: solid 1px black;
  border-radius: 10px;
}

.page-4th-1st-part > img {
  position: relative;
  left: 30px;
  top: 20px;
  height: 40px;
  width: 40px;
}

.notif-bar {
  margin: 5px 10px;
  background-color: white;
}

.page-4th-2nd-part {
}
</style>

