 <template>
  <div class="container">
    <div class="navbar">
      <p class="appTitle">{{ appTitle }}</p>
      <u-icon name="email" class="iconMail"></u-icon>
    </div>  
      
    <div class="search">
      <u-search :clearabled="true" class="search-box" placeholder="Search" shape="square" v-model="keyword" bg-color="white"></u-search>
    </div>

    <div >
      <div>
        <view class="content">
          <view class="wrap">
            <u-swiper :list="carouselList"></u-swiper>
          </view>
        </view>
      </div>

      <div class="">
        <div class="columns1">
          <div>19家</div>
          <div>42单</div>
          <div>77单</div>
        </div>

        <div class="columns2">
          <div>入驻企业</div>
          <div>促成交易</div>
          <div>正在竞价</div>
        </div>
      </div>

      <div>
        <swiper class="swiper" @change="change">
          <swiper-item>
            <u-grid :col="4" @click="click" hover-class="hover-class">
              <u-grid-item v-for="(item, index) in navlistone" :index="index" :key="index" v-if="index<8">
                <!-- <u-icon :name="item.app_icon" :size="46"></u-icon> -->
                <text class="grid-text">{{ item.id }}</text>
              </u-grid-item>
            </u-grid>
          </swiper-item>
        <swiper-item>
          <u-grid :col="4" @click="click" hover-class="hover-class">
            <u-grid-item v-for="(item, index) in navlisttwo" :index="index" :key="index">
              <u-icon :name="item" :size="46"></u-icon>
              <text class="grid-text">{{ '宫格' + (index + 1) }}</text>
            </u-grid-item>
          </u-grid>
        </swiper-item>
      </swiper>
        <view class="indicator-dots" v-if="isSwiper">
          <view class="indicator-dots-item" :class="[current == 0 ? 'indicator-dots-active' : '']">
          </view>
          <view class="indicator-dots-item" :class="[current == 1 ? 'indicator-dots-active' : '']">
          </view>	
        </view>
      </div>



      <div>
        <div class="cell">
          <u-cell-group>
            <u-cell-item icon="tags" title="个人设置"></u-cell-item><hr style="margin: 0 5%">
            <view>
              <scroll-view style="height:50rpx" :scroll-top="scrollTop" scroll-y="true" class="scroll-Y" @scrolltoupper="upper" @scrolltolower="lower"
                @scroll="scroll">
                    <li v-for="(item, index) in items" :key="index" class="scroll-list">
                      <!-- {{ item }} -->
                      <view class="scroll-view-item uni-bg-red demo1">
                        <section>
                          <span>标题：{{ item.title }}</span>
                          <span>{{ item.nav_title?item.nav_title:'null' }}</span>
                          <span>类型：{{ item.project?item.project.project:'' }}</span>
                        </section><hr style="margin-top:1px">
                        <aside>
                          <span>{{ item.created_at.substring(5,10) }}</span>
                          <p>竞价参与人数：0 人</p>
                        </aside>
                      </view>
                    </li>
              </scroll-view>
            </view>
          </u-cell-group>
        </div>

        <div class="news">
          <u-tabs :list="listTab" :is-scroll="false" :current="listCurrent" @change="listChange"></u-tabs>
          <div class="content">
              <u-card >
                <view class="" slot="body" v-for="(card, types) in cards" :key="types">
                  <view class="u-body-item u-flex u-border-bottom u-col-between u-p-t-0">
                    <view class="u-body-item-title u-line-2">{{ card.nav_title }}</view>
                    <u-image :src="card.news_img" :fade="true" duration="450">
                      <u-loading slot="error"></u-loading>
                    </u-image>
                  </view>
                  <view class="" slot="foot"><u-icon name="" size="34" color="" :label="card.title"></u-icon></view>
                </view>
              </u-card>
            </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      appTitle: "供应链让模具定制更简单",
      radio: "1",
      keyword: "Search",
      carouselList: [
        {
          image: "https://cdn.uviewui.com/uview/swiper/1.jpg",
          title: "昨夜星辰昨夜风，画楼西畔桂堂东",
        },
        {
          image: "https://cdn.uviewui.com/uview/swiper/2.jpg",
          title: "身无彩凤双飞翼，心有灵犀一点通",
        },
        {
          image: "https://cdn.uviewui.com/uview/swiper/3.jpg",
          title: "谁念西风独自凉，萧萧黄叶闭疏窗，沉思往事立残阳",
        },
      ],
      current: 0,
      items: [],
      navlistone: [
        "integral",
        "kefu-ermai",
        "coupon",
        "gift",
        "scan",
        "pause-circle",
        "wifi",
        "email",
      ],
      navlisttwo: ["integral", "kefu-ermai"],
      isSwiper: true,
      scrollTop: 0,
      old: {
        scrollTop: 0,
      },
      listTab: [
        {
          name: "企业新闻",
        },
        {
          name: "行业新闻",
        },
      ],
      listCurrent: 0,
      // title: "素胚勾勒出青花",
      cards: [],
      types: "enterprise",
      thumb: "http://pic2.sc.chinaz.com/Files/pic/pic9/202002/hpic2119_s.jpg",
    };
  },
  onLoad() {
    uni.request({
      url: "https://gyltest.mouldc.com/api/carousel", //仅为示例，并非真实接口地址。
      method: "POST",
      header: {
        "custom-header": "hello", //自定义请求头信息
      },
      success: (res) => {
        console.log(res.data.image);
        this.carouselList = res.data.image;
        let imageArr = res.data.image;
        let arr = [];
        imageArr.forEach((element) => {
          let obj = {
            image: element.image,
          };
          arr.push(obj);
        });
        console.log(arr);
      },
    });

    uni.request({
      url: "https://gyltest.mouldc.com/api/registration/technology",
      method: "POST",
      header: {
        "custom-header": "hello",
      },
      success: (res) => {
        console.log(res.data.model);
        this.navlistone = res.data.model;
      },
    });

    let that = this;
    uni.request({
      url: "https://gyltest.mouldc.com/api/mould",
      method: "POST",
      success: (res) => {
        that.items = res.data.mould;
        console.log(res.data.mould);
      },
    });


    uni.request({
      url: "https://gyltest.mouldc.com/api/news",
      data: {
        types: this.types,
        page: 1,
      },
      method: "POST",
      success: (res) => {
        console.log(res.data.news.data);
        that.cards = res.data.news.data;
      },
    });
  },
  methods: {
    change(e) {
      this.current = e.detail.current;
      console.log(this.current);
    },
    upper: function(e) {
      console.log(e);
    },
    lower: function(e) {
      console.log(e);
    },
    scroll: function(e) {
      console.log(e);
      this.old.scrollTop = e.detail.scrollTop;
    },
    goTop: function(e) {
      this.scrollTop = this.old.scrollTop;
      this.$nextTick(function() {
        this.scrollTop = 0;
      });
      uni.showToast({
        icon: "none",
        title: "纵向滚动 scrollTop 值已被修改为 0",
      });
    },
    listChange(index) {
      if(index == 0) {
        this.types = "enterprise";  
      } else if(index == 1) {
          this.types = "industry";
      }

      this.listCurrent = index;
      uni.request({
        url: "https://gyltest.mouldc.com/api/news",
        data: {
          types: this.types,
        },
        method: "POST",
        success: (res) => {
          console.log(res.data.news.data);
          this.cards = res.data.news.data;
          // this.types = this.listCurrent;
        },
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.container {
  background-color: #eff5f5;
  height: 100%;
}

.appTitle {
  display: inline;
  text-align: center;
  margin-left: 100px;
  font-weight: 700;
}

.wrap {
  padding: 40rpx;
}

.iconMail {
  float: right;
  margin-right: 10px;
}

.columns1,
.columns2 {
  display: flex;
  margin: 0 20px;
  color: rgba(88, 171, 204, 0.918);
}

.columns1 > div,
.columns2 > div {
  flex: 1;
}

.search {
  margin-top: 5px;
}

.search-box {
  position: relative;
  left: 5px;
}

.grid-text {
  font-size: 28rpx;
  margin-top: 4rpx;
  color: $u-type-info;
}

/* 下方这些scss变量为uView内置变量，详见开发  组件-指南-内置样式 */

.grid-text {
  font-size: 28rpx;
  margin-top: 4rpx;
  color: $u-type-info;
}

.swiper {
  height: 280rpx;
}

.indicator-dots {
  margin-top: 40rpx;
  display: flex;
  justify-content: center;
  align-items: center;
}

.indicator-dots-item {
  background-color: $u-tips-color;
  height: 6px;
  width: 6px;
  border-radius: 10px;
  margin: 0 3px;
}

.indicator-dots-active {
  background-color: $u-type-primary;
}

.scroll-Y,
// .cell,
#demo1,
#demo2,
#demo3 {
  margin-top: 7px;
}

.cell {
  margin: 30px 5px;
  height: 140px;
}

.scroll-Y {
  min-height: 90px;
}

.page-4th {
  height: 700px;
}

.page-4th-1st-part {
  width: 98%;
  height: 150px;
  margin: 10px 2px;
  background-color: rgb(224, 237, 242);
  border: solid 1px black;
  border-radius: 10px;
}

.page-4th-1st-part > img {
  position: relative;
  left: 30px;
  top: 20px;
  height: 40px;
  width: 40px;
}

.notif-bar {
  margin: 5px 10px;
  background-color: white;
}

.scroll-list {
  list-style: none;
  padding: 3px;
  margin: 3px;
}

.demo1 {
  display: inline;
  position: relative;
}

.demo1 > section {
  width: 200px;
  line-height: 1.5;
}

section > span {
  display: block;
}

.demo1 > aside {
  width: 150px;
  padding: 2px;
  margin: 2px;
  float: right;
  position: relative;
  top: -54px;
}

.demo1 > aside > p {
  position: relative;
  top: 5px;
  color: red;
}

.demo1 > aside > span {
  position: relative;
  left: 90px;
  top: -15px;
}

.u-card-wrap {
  background-color: $u-bg-color;
  padding: 1px;
}

.u-body-item {
  font-size: 32rpx;
  color: #333;
  padding: 20rpx 10rpx;
}

.u-body-item image {
  width: 120rpx;
  flex: 0 0 120rpx;
  height: 120rpx;
  border-radius: 8rpx;
  margin-left: 12rpx;
}
</style>

