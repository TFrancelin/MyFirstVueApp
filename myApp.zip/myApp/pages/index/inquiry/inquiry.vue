<template>
	<view class="container">
		<div class="navbar">
			<p class="appTitle">{{ appTitle }}</p>
			<u-icon name="email" class="iconMail"></u-icon>
		</div>
		
		<div class="search">
			<u-search :clearabled="true" class="search-box" placeholder="Search" shape="square" v-model="keyword" bg-color="white"></u-search>
		</div>

		<div class="drop">
			<view class="">
				<u-dropdown>
					<u-dropdown-item v-model="value" title="类型" :options="options1" @change="clickOptions1"></u-dropdown-item>
					<u-dropdown-item v-model="value2" title="默认" :options="options2"></u-dropdown-item>
					<u-dropdown-item v-model="value3" title="时间" :options="options3"></u-dropdown-item>
					<u-dropdown-item v-model="value4" title="生产周期" :options="options4" @change="clickOptions4"></u-dropdown-item>
					<u-dropdown-item v-model="value5" title="状态" :options="options5"></u-dropdown-item>
				</u-dropdown>
			</view>
		</div>
			
		<div>
			<u-card :title="title + inquiry.no" :sub-title="subTitle" v-for="(inquiry, index) in inquiries" :key="index" @click="clickCard(inquiry)">
				<view class="card" slot="body">
					<view class="u-body-item u-flex u-border-bottom u-col-between u-p-t-0">
						<image :src="inquiry.image[0]" mode="aspectFill"/>
						<view class="u-body-item-title u-line-2" style="width:100%">
							<view class="u-body-item-title-first">
								<p>标题：{{ inquiry.title }}</p>
								<p class="textToOverflow" style="color:gray">工艺需求：{{ inquiry.technology }}</p>
								<p>类型：{{ inquiry.project?inquiry.project.project:' ' }}</p>
							</view>
							<view class="u-body-item-title-second">
								<p>{{ inquiry.updated_at.substring(6, 11) }}发布</p>
								
								<p>生产周期：{{ inquiry.day }}天</p>
							</view>
						</view>	
					</view>
				</view>
			</u-card>

		</div>
	</view>
</template>

<script>
export default {
  data() {
    return {
      appTitle: "供应链让模具定制更简单",
      radio: "1",
      keyword: "Search",
      title: "订单编号: ",
      subTitle: "正在竞价",
      thumb: "http://pic2.sc.chinaz.com/Files/pic/pic9/202002/hpic2119_s.jpg",
      inquiries: [],
      options1: [],
      options2: [],
      options3: [
        {
          label: "Ascendant to descendant",
          value: 1,
        },
        {
          label: "Descendant to ascendant",
          value: 2,
        },
      ],
      options4: [
        {
          label: "Ascendant",
          value: 1,
        },
        {
          label: "Descendant",
          value: 2,
        },
      ],
      options5: [],
      value: null,
      value3: null,
      value4: null,
    };
  },
  onLoad() {
    let that = this;

    uni.request({
      url: "https://gyltest.mouldc.com/api/registration/technology",
      method: "POST",
      success: (res) => {
        console.log(res.data.model);
        let categories = res.data.model.map((item) => {
          return {
            label: item.project,
            value: item.id,
          };
        });
        that.options1 = categories;
        console.log(categories);
      },
    });

    uni.request({
      url: "https://gyltest.mouldc.com/api/inquiry/type",
      data: {
        props: [this.value],
      },
      method: "POST",
      data: {},
      success: (res) => {
        console.log(res.data.data.data);
        that.inquiries = res.data.data.data;
      },
    });
  },
  methods: {
    clickOptions1(item) {
      let that = this;
      var arr = [item];
      console.log(item);
      uni.request({
        url: "https://gyltest.mouldc.com/api/inquiry/type",
        data: {
          pros: JSON.stringify(arr),
        },
        method: "POST",
        success: (res) => {
          console.log(res.data.data.data);
          that.inquiries = res.data.data.data;
        },
      });
    },

    clickOptions4(item) {
      if (item == 1) {
        this.value4 = "asc";
      } else if (item == 2) {
        this.value4 = "desc";
      }
      // this.value4 = item;
      console.log(item);
      console.log(this.value4);
      let that = this;
      uni.request({
        url: "https://gyltest.mouldc.com/api/inquiry/type",
        data: {
          prop: this.value4,
          value: "day",
        },
        method: "POST",
        success: (res) => {
          that.inquiries = res.data.data.data;
          console.log(res.data.data.data);
        },
      });
    },

    clickCard(inquiry) {
      console.log(inquiry);
      let that = this;
      uni.navigateTo({
        url: "../products/prodInformations?id=" + inquiry.id,
        events: {
          acceptDataFromOpenedPage: function(data) {
            // id = this.inquiries;
            console.log(data);
          },
          someEvent: function(data) {
            // id = this.inquiries;
            console.log(data);
          },
        },

        success: (res) => {
          (that.id = res.data.data.data.id),
            res.eventChannel.emit("acceptDataFromOpenerPage", { data: "id" });
        },
      });
    },
  },
  watch: {
    value3: function(val) {
      console.log(val);
      if (val == 1) {
        val = "asc";
      } else if (val == 2) {
        val = "desc";
      }
      let that = this;

      uni.request({
        url: "https://gyltest.mouldc.com/api/inquiry/type",
        data: {
          prop: val,
          value: "created_at",
        },
        method: "POST",
        success: (res) => {
          console.log(res.data.data.data);
          that.inquiries = res.data.data.data;
        },
      });
    },
  },
};
</script>

<style lang="scss">
.container {
  background-color: rgba(248, 246, 246, 0.925);
}

.appTitle {
  display: inline;
  text-align: center;
  margin-left: 100px;
  font-weight: 700;
}

// .u-card-wrap {
//   background-color: $u-bg-color;
//   padding: 1px;
// }

// .u-border-bottom {
//   padding: 4px;
// }

// .card {
// 	padding: 1px;
// }

.u-body-item {
  font-size: 25rpx;
  color: #333;
  padding: 30rpx 1rpx;
}

.u-body-item image {
  width: 120rpx;
  flex: 0 0 100rpx;
  height: 120rpx;
  border-radius: 8rpx;
  margin-left: 5rpx;
}

.u-body-item-title {
  display: flex;
  max-width: 600px;
  line-height: 1.6;
}

.u-body-item-title-first {
  flex: 4;
  margin-right: 20px;
}

.u-body-item-title-first > p {
  width: 110px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.u-body-item-title-second {
  flex: 3;
  width: 90px;
}

.u-body-item-title-second > p:last-child {
  position: relative;
  top: 18px;
}

.u-body-item-title.u-line-2 {
  margin: 0 5px;
}

.pd-right-4 {
  padding-right: 40px;
}
</style>
