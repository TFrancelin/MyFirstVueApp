<template>
	<view class="container">
		<div class="navbar">
			<p class="appTitle">{{ appTitle }}</p>
			<u-icon name="email" class="iconMail"></u-icon>
		</div>
		
		<div class="search">
			<u-search :clearabled="true" class="search-box" placeholder="Search" shape="square" v-model="keyword" bg-color="white"></u-search>
		</div>
			
		<div>
			<u-card :title="title" :sub-title="subTitle">
				<view class="" slot="body">
					<view class="u-body-item u-flex u-border-bottom u-col-between u-p-t-0">
						<image src="https://img11.360buyimg.com/n7/jfs/t1/94448/29/2734/524808/5dd4cc16E990dfb6b/59c256f85a8c3757.jpg" mode="aspectFill"/>
						<view class="u-body-item-title u-line-2 pd-right-4">瓶身描绘的牡丹一如你初妆，冉冉檀香透过窗心事我了然，宣纸上走笔至此搁一半</view>	
					</view>
				</view>
			</u-card>

			<u-card :title="title" :sub-title="subTitle">
				<view class="" slot="body">
					<view class="u-body-item u-flex u-border-bottom u-col-between u-p-t-0">
						<image src="https://img12.360buyimg.com/n7/jfs/t1/102191/19/9072/330688/5e0af7cfE17698872/c91c00d713bf729a.jpg" mode="aspectFill"/>
						<view class="u-body-item-title u-line-2">瓶身描绘的牡丹一如你初妆，冉冉檀香透过窗心事我了然，宣纸上走笔至此搁一半</view>			
					</view>
				</view>
			</u-card>

			<u-card :title="title" :sub-title="subTitle">
				<view class="" slot="body">
					<view class="u-body-item u-flex u-border-bottom u-col-between u-p-t-0">
						<image src="https://img11.360buyimg.com/n7/jfs/t1/94448/29/2734/524808/5dd4cc16E990dfb6b/59c256f85a8c3757.jpg" mode="aspectFill"/>
						<view class="u-body-item-title u-line-2">瓶身描绘的牡丹一如你初妆，冉冉檀香透过窗心事我了然，宣纸上走笔至此搁一半</view>
					</view>
				</view>
			</u-card>

			<u-card :title="title" :sub-title="subTitle">
				<view class="" slot="body">
					<view class="u-body-item u-flex u-border-bottom u-col-between u-p-t-0">
						<image src="https://img12.360buyimg.com/n7/jfs/t1/102191/19/9072/330688/5e0af7cfE17698872/c91c00d713bf729a.jpg" mode="aspectFill"/>
						<view class="u-body-item-title u-line-2">瓶身描绘的牡丹一如你初妆，冉冉檀香透过窗心事我了然，宣纸上走笔至此搁一半</view>			
					</view>
				</view>
			</u-card>

			<u-card :title="title" :sub-title="subTitle">
				<view class="" slot="body">
					<view class="u-body-item u-flex u-border-bottom u-col-between u-p-t-0">
						<image src="https://img11.360buyimg.com/n7/jfs/t1/94448/29/2734/524808/5dd4cc16E990dfb6b/59c256f85a8c3757.jpg" mode="aspectFill"/>
						<view class="u-body-item-title u-line-2">瓶身描绘的牡丹一如你初妆，冉冉檀香透过窗心事我了然，宣纸上走笔至此搁一半</view>
					</view>
				</view>
			</u-card>

			<u-card :title="title" :sub-title="subTitle">
				<view class="" slot="body">
					<view class="u-body-item u-flex u-border-bottom u-col-between u-p-t-0">
						<image src="https://img12.360buyimg.com/n7/jfs/t1/102191/19/9072/330688/5e0af7cfE17698872/c91c00d713bf729a.jpg" mode="aspectFill"/>
						<view class="u-body-item-title u-line-2">瓶身描绘的牡丹一如你初妆，冉冉檀香透过窗心事我了然，宣纸上走笔至此搁一半</view>
					</view>
				</view>
			</u-card>

			<u-card :title="title" :sub-title="subTitle">
				<view class="" slot="body">
					<view class="u-body-item u-flex u-border-bottom u-col-between u-p-t-0">
						<image src="https://img11.360buyimg.com/n7/jfs/t1/94448/29/2734/524808/5dd4cc16E990dfb6b/59c256f85a8c3757.jpg" mode="aspectFill"></image>
						<view class="u-body-item-title u-line-2">瓶身描绘的牡丹一如你初妆，冉冉檀香透过窗心事我了然，宣纸上走笔至此搁一半</view>
					</view>
				</view>
			</u-card>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				appTitle: "供应链让模具定制更简单",
        radio: "1",
        keyword: "Search",
        title: '订单编号： 2021072368445',
			  subTitle: '正在竞价',
			  thumb: 'http://pic2.sc.chinaz.com/Files/pic/pic9/202002/hpic2119_s.jpg',
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: rgba(248, 246, 246, 0.925);
	}

	.appTitle {
		display: inline;
		text-align: center;
		margin-left: 100px;
		font-weight: 700;
	}

	.u-card-wrap { 
			background-color: $u-bg-color;
			padding: 1px;
		}
	
	.u-body-item {
		font-size: 32rpx;
		color: #333;
		padding: 20rpx 10rpx;
	}
		
	.u-body-item image {
		width: 120rpx;
		flex: 0 0 120rpx;
		height: 120rpx;
		border-radius: 8rpx;
		margin-left: 5rpx;
    
	}

	.u-body-item-title.u-line-2 {
		margin: 0 5px;
	}

	.pd-right-4{
		padding-right: 40px;
	}

</style>
