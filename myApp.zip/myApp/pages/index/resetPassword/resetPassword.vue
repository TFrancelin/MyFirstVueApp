<template>
    <div class="container">
        <div>
            <div class="first-section">
                <h4>找回密码</h4>
                <p>我们将帮助您找回密码</p>
                <img src="https://obs-sm-store.obs.cn-east-3.myhuaweicloud.com//assets/images/LOGO.png" alt="zhongmoyun">
            </div>
        </div>

        <div class="second-section">
          <p>手机号</p>
            <div class="fill-section">
              <div class="phone-section">
                <p>+86</p>
              </div>
              <div class="fill-number-section">
                <input v-model="mobile" type="number"><hr>
              </div>
            </div> 

            <div class="icon">
                <u-icon @click="arrowClick" name="arrow-rightward" size="35"></u-icon>
            </div>
        </div>
    </div>
    
    
</template>

<script>
export default {
  data() {
    return {
      mobile: "",
    };
  },

  methods: {
    arrowClick() {
      uni.navigateTo({
        url: "../newUser/newUser",
        animationType: "pop-in",
      });
    }
  },
};
</script>

<style lang="scss">
.first-section {
  margin: 20px;

  img {
  position: relative;
  float: right;
  top: -40px;
  height: 40px;
  width: 40px;
  border: 2px solid rgba(255, 255, 255, 0.945);
//   border-radius: 50%;
  }
}

.second-section {
    margin: 20px;
}

.fill-section {
  display: flex;
}

.phone-section>p {
  font-size: 15px;
  margin-top: 1px;
}

.fill-number-section {
  margin-left: 20px;
}

.fill-number-section>input {
  font-size: 15px;
}

.icon {
    text-align: center;
    position: relative;
    top: 20px;
}


</style>
