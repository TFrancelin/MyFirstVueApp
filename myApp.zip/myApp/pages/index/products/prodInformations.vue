<template>
    <view class="container">
        <view class="carousel">
		    <u-image :src="item.image[0]" width="100%" height="300rpx"><u-loading slot="loading"></u-loading></u-image>
        </view>

        <div class="updatedAt">
            <p>{{ item.title }}</p>
            <p>{{ item.updated_at }}更新</p>
        </div>

        <div class="parameters">
            <p><span class="first-span">参数</span><span class="second-span">模具类型</span><span class="third-span">{{ item.project? item.project.project:'' }}</span></p>
            <p><span class="first-span">参数</span><span class="second-span">生产周期</span><span class="third-span">{{ item.day }}</span></p>
            <p><span class="first-span">参数</span><span class="second-span">预付款和尾款比例</span><span class="third-span">{{ item.advance }}:{{ item.balance }}</span></p>
            <p><span class="first-span">参数</span><span class="second-span">3D图纸</span><span class="third-span">图纸生成中</span></p>
            <p><span class="first-span">参数</span><span class="second-span">厂家条件</span><span class="third-span"></span></p>
        </div>

        <div class="moldRequirement">
            <p>模具需求</p>
            <p>腔数：{{ item.make_num }}</p>
            <p>模具寿命（次）：{{ item.mould_life }}</p>
            <p>{{ item.technology?item.technology: '暂无' }}</p>
        </div>

        <div class="sampleRequirement">
            <p>产品需求</p>
            <p>{{ item.product_demand }} 产品产量：{{ item.yield }}</p>
        </div>

        <div v-for="(collection, index) in collections" :key="index">
            <p>{{ collection.title }}</p>
            <u-empty text="暂无数据" mode="list"></u-empty>
        </div>

        <view>
            <u-divider half-width="150" border-color="#6d6d6d">相关推荐</u-divider>
        </view>

        <view class="card">
            <view v-for="(card, index) in cards" :key="card+index" @click="clickProduct(card)">
                    <img :src="card.image[0]" alt="product image">
                    <p>{{ card.title }}</p>
                    <p>{{ card.updated_at }}</p>
            </view>
        </view>
    </view>
</template>

<script>
export default {
  data() {
    return {
      item: {},
      collections: [
        {
          title: "材料需求",
          index: 1
        },
        {
          title: "设备需求",
          index: 2
        },
        {
          title: "配件需求",
          index: 3
        },
        {
          title: "备注",
          index: 4
        }
      ],
      cards: []
    };
  },
  methods: {
    console(text, code) {
      console.log(text, code);
    },
    // console();
    clickProduct(item) {
      var str = "hello world ";
      this.console(str, item);

      console.log(item);
      uni.redirectTo({
        url: "../products/prodInformations?id=" + item.id
      });

      let that = this;

      uni.request({
        url: "https://gyltest.mouldc.com/api/mould/obtaindetails",
        method: "POST",
        data: {
          id: item.id
        },
        success: res => {
          console.log(res.data.data);
          that.item = res.data.data;
          that.cards = res.data.recommendations;
        }
      });
    }
  },
  onLoad(option) {
    // console.log(option);

    // const eventChannel = this.$scope.eventChannel;
    // const eventChannel = this.getOpenerEventChannel();

    // eventChannel.emit('acceptDataFromOpenedPage', {data: 'id'});
    // eventChannel.emit('someEvent', {data: 'id'});
    // eventChannel.on('acceptDataFromOpenerPage', function(id) {
    //     console.log(id);
    // })
    console.log(option);
    let that = this;

    uni.request({
      url: "https://gyltest.mouldc.com/api/mould/obtaindetails",
      method: "POST",
      data: {
        id: option.id
      },
      success: res => {
        console.log(res.data.data);
        that.item = res.data.data;
        that.cards = res.data.recommendations;
      }
    });
  }
};
</script>

<style lang="scss">
.updatedAt {
  margin: 10px;
  padding: 8px;
  line-height: 1.7;
  border: solid 1px rgb(244, 244, 244);
  border-radius: 10rpx;
}

div {
  border: 1px solid whitesmoke;
  border-radius: 10rpx;
  margin: 10px;
  padding: 5px;
  line-height: 1.5;
}

.parameters > p {
  display: flex;
}

.first-span {
  color: rgba(53, 52, 52, 0.384);
}

.first-span,
.third-span {
  flex: 1;
}

.second-span {
  flex: 3;
}

.card {
  width: 320px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  width: 100%;
}

.card > view {
  border: 1px solid whitesmoke;
  border-radius: 10rpx;
  margin: 5px;
  padding: 5px;
  width: 175px;
}

.card > view > img {
  width: 120px;
  height: 120px;
  text-align: center;
}
</style>
