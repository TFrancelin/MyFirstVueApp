<template>
    <div class="container">   
        <div class="navBar">
            <view>
                <h3>欢迎入驻供应链</h3>
                <p>请先填写资料</p>
            </view>
            <view class="logos">
                <img class="compLogo" src="https://obs-sm-store.obs.cn-east-3.myhuaweicloud.com//assets/images/LOGO.png" alt="zhongmoyun logo">
                <u-icon class="rewind-right" name="rewind-right" size="35"></u-icon>
                <u-icon class="star" @click="premiumClick" name="star-fill" size="85"></u-icon>
            </view>
        </div>
        <div class="step">
          <view class="steps">
		          <u-steps :list="numList" :current="0"  active-color="#87CEEB"></u-steps>
	          </view>
        </div>

        <div class="first-step">
            <p>手机号</p>
            <h3>+86</h3>
            <div class="passCode">
              <input v-model="mobile" type="number"><hr style="margin: 0 30px 0 0 ">
              <u-verification-code :seconds="seconds" @end="end" @start="start" ref="uCode" @change="codeChange"></u-verification-code>
            </div>
            <p class="get-code" @tap="getCode">{{tips}}</p>
            <p class="labeling">暂只支持中国大陆手机号</p>
        </div>
        <div class="icon">
          <view>
            <u-icon @click="arrowClick" name="arrow-rightward" size="85"></u-icon>
          </view>
          <view @click="cancelClick">
            <u-icon name="close-circle" size="30"></u-icon><p style="display:inline">关闭</p>
          </view>
        </div>
    </div>
    
</template>


<script>
export default {
  data() {
    return {
      tips: "",
      seconds: 60,
      numList: [
        {
          name: "验证手机",
        },
        {
          name: "选择身份",
        },
        {
          name: "信息填写",
        },
        {
          name: "注册成功",
        },
      ],
    };
  },
  onLoad() {},
  methods: {
    codeChange(text) {
      this.tips = text;
    },
    getCode() {
      if (this.$refs.uCode.canGetCode) {
        // 模拟向后端请求验证码
        uni.showLoading({
          title: "正在获取验证码",
        });
        setTimeout(() => {
          uni.hideLoading();
          // 这里此提示会被this.start()方法中的提示覆盖
          this.$u.toast("验证码已发送");
          // 通知验证码组件内部开始倒计时
          this.$refs.uCode.start();
        }, 2000);
      } else {
        this.$u.toast("倒计时结束后再发送");
      }
    },
    end() {
      this.$u.toast("倒计时结束");
    },
    start() {
      this.$u.toast("倒计时开始");
    },
  },
};
</script>

<style lang="scss">
.navBar {
  display: flex;
  margin: 10px;
}

.navBar > view {
  flex: 1;
  align-content: space-around;
}

.logos {
  position: relative;
  left: 60px;
}

.compLogo {
  width: 40px;
  height: 40px;
  position: relative;
  top: 4px;
  right: 5px;
}

.rewind-right {
  position: relative;
  left: 10px;
  top: -10px;
}

.star {
  position: relative;
  left: 20px;
}

.steps {
  margin: 20px 0 0 0;
}

.first-step {
  height: 80px;
  border: 1px solid rgb(235, 235, 235);
  border-radius: 10px;
  position: relative;
  margin: 40px 5px;
  padding: 10px;
}

.passCode {
  position: relative;
  width: 270px;
  float: left;
}

.get-code {
  position: relative;
  float: right;
  color: skyblue;
}

.labeling {
  position: relative;
  float: left;
  color: gray;
}

.icon {
  text-align: center;
  display: block;
}
</style>
