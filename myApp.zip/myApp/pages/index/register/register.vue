<template>
    <div>   
        <div class="navBar">
            <view>
                <h3>欢迎入驻供应链</h3>
                <p>请先填写资料</p>
            </view>
            <view class="logos">
                <img class="compLogo" src="https://obs-sm-store.obs.cn-east-3.myhuaweicloud.com//assets/images/LOGO.png" alt="zhongmoyun logo">
                <u-icon class="rewind-right" @click="arrowClick" name="rewind-right" size="35"></u-icon>
                <u-icon class="star" @click="premiumClick" name="star" size="85"></u-icon>
            </view>
        </div>

        <div class="first-step">
            <p>手机号</p>
            <h3>+86</h3>
            <input v-model="mobile" type="number"><hr style="margin: 0 20px">
            <u-verification-code :seconds="seconds" @end="end" @start="start" ref="uCode" @change="codeChange"></u-verification-code>
            <u-button class="wrap" @tap="getCode">{{tips}}</u-button>
        </div>
    </div>
    
</template>


<script>
export default {};
</script>

<style lang="scss">
.navBar {
  display: flex;
  margin: 10px;
}

.navBar > view {
  flex: 1;
  align-content: space-around;
}

.logos {
  position: relative;
  left: 60px;
}

.compLogo {
  width: 40px;
  height: 40px;
  position: relative;
  top: 4px;
  right: 5px;
}

.rewind-right {
  position: relative;
  left: 10px;
  top: -10px;
}

.star {
  position: relative;
  left: 20px;
}
</style>
